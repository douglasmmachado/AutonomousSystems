%---------- Computer lab Autonomous Systems ----------
%-------------- Master MARS - 3A ASI -----------------
%--------------- Lara BRINON ARRANZ ------------------

% ----------------- STUDENTS FILE --------------------
%% Flocking for double integrator robots

% robot model
% pi = [xi;yi]
% vi = [vix;viy]
% double integrator
% pi_dot = vi
% vi_dot = ui

init;

% simulation parameters
%number of robots
N=20;

% sampling time
dt=1/(2*N);

% iterations
T=200;


% Variables to be used in the simulation
% vector of all robot states P=[p1;p2;...;pN] 
% X=[x1;x2;...;xN] Y=[y1;y2;...;yN]
% We keep in memory the values at each iteration k
X=zeros(N,T);
Y=zeros(N,T);

% random robot initial states
P0=20*randn(N,2);
X(:,1)=P0(:,1);
Y(:,1)=P0(:,2);

V0=5+10*randn(N,2);
Vx=V0(:,1);
Vy=V0(:,2);


% vector of all control inputs U=[u1;u2;...;uN]
% Ux=[ux1;ux2;...;uxN] Uy=[uy1;uy2;...;uyN]
% we update the value of U at each iteration k in the same variable
% initial conditions for control inputs
Ux=zeros(N,1);
Uy=zeros(N,1);


% SIMULATION
for k=2:T
    clf();
    axis([-60,60,-60,60]);
    axis square; hold on

    % control parameters
    alpha=1;
    beta=1;
    gamma=1;

    for i=1:N
        % control law for robot i
        Ux(i)=0;
        Uy(i)=0;
        
        % alignment
        
        % cohesion
        
        % separation
        
        
        % update the state of robot i using its dynamics
        Vx(i,k)=Vx(i,k-1);
        Vy(i,k)=Vy(i,k-1);
        X(i,k)=X(i,k-1);
        Y(i,k)=Y(i,k-1);

        % draw the robots as circles
        plot(X(i,k),Y(i,k),'oblack','LineWidth',3)
        % draw the robots' velocities as arrows
        quiver(X(i,k),Y(i,k),Vx(i,k),Vy(i,k),'LineWidth',2)
    
    end
    drawnow();
end

%% Figure
figure 
% plot the robots' initial positions in red
plot(X(:,1),Y(:,1),'ored','LineWidth',3);
hold on
axis square;
% draw the robots' initial velocities as arrows
for i=1:N
    quiver(X(i,1),Y(i,1),Vx(i,1),Vy(i,1),'r','LineWidth',1)
end

% plot the robots' trajectories in black


% plot the robots' final positions in blue


% draw the robots' final velocities as arrows

hold off

figure
% plot the robots' velocities over time
subplot(2,1,1);

subplot(2,1,2); 
   
figure
% plot the robots' positions over time
subplot(2,1,1);

subplot(2,1,2);